#pragma once

extern char* heap;
extern int heapSize;

void createHeap();