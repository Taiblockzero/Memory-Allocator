#pragma once

//If pBlock is NULL, myFree does nothing
void myFree(char* pBlock);