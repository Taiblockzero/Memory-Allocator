#pragma once

const short int INT_SIZE = 4;
const short int ALIGNMENT = 8;